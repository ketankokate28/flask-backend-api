"""Abstract base classes."""

from rasterio._vsiopener import FileContainer, MultiByteRangeResourceContainer  # noqa: F401
