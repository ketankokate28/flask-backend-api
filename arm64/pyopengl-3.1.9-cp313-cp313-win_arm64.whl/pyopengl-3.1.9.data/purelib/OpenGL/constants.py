"""Backward-compatibility module to provide core-GL constant names"""
from OpenGL.raw.GL._types import *
from OpenGL.arrays._arrayconstants import *
