"C:\Python313-arm64\python.exe" "C:\Python313-arm64\Lib\site-packages\pymol\__init__.py" %*
