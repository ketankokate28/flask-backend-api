# init for simulations
