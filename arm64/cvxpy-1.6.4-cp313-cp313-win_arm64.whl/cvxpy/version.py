
# THIS FILE IS GENERATED FROM CVXPY SETUP.PY
short_version = '1.6.4'
version = '1.6.4'
full_version = '1.6.4'
git_revision = '78b54aa'
commit_count = '78b54aa'
release = True
if not release:
    version = full_version
