def gmatmul_canon(expr, args):
    return expr.A @ args[0], []
