# -----------------------------------------------------------------------------
# Copyright (c) 2009-2016 Nicolas P. Rougier. All rights reserved.
# Distributed under the (new) BSD License.
# -----------------------------------------------------------------------------
__backends__ = ('glfw_deprecated',
                'glfw',
                'glfw_imgui',
                'pyglet',
                'sdl',
                'sdl2',
                'osxglut',
                'freeglut',
                'qt5',
                'pyside',
                'pyside2')
