
INCLUDES=['C:\\Program Files\\Microsoft\\jdk-21.0.6.7-hotspot\\bin\\..\\/include', 'C:\\Program Files\\Microsoft\\jdk-21.0.6.7-hotspot\\bin\\..\\/include/win32']
CFLAGS=['/EHsc', '/D_CRT_SECURE_NO_WARNINGS']
DEBUG_CFLAGS=['/Od', '/DDEBUG']
LFLAGS=['/DLL', '/LIBPATH:C:\\Program Files\\Microsoft\\jdk-21.0.6.7-hotspot\\bin\\..\\/lib', 'Ws2_32.lib', 'jvm.lib']
IMPLIB_LFLAGS=['/IMPLIB:%s']
SHARED=False
VERSION="3.15"
