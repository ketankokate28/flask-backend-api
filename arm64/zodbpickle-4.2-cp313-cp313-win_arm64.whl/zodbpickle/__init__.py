__all__ = [
    'binary',
]

binary = bytes
