__version__ = "3.10.2"
"""The PyTables version number."""
