"""Module for CP2K input/output parsing as well as sets for standard calculations."""

from __future__ import annotations

__author__ = "Nicholas Winner"
