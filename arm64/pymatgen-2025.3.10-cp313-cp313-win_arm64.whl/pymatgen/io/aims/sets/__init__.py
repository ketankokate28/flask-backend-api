from __future__ import annotations

from pymatgen.io.aims.sets.base import AimsInputSet
