"""Module for predicting topological properties."""
