"""This package provides the modules for performing large scale transformations on
a large number of structures.
"""
