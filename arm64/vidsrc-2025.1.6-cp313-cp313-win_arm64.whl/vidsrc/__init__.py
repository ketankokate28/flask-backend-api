# -*- coding: utf-8 -*-
# vidsrc/__init__.py

__all__ = ['__version__', 'VideoSource']

from .vidsrc import VideoSource, __doc__, __version__
