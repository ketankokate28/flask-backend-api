FT_Color_Root_Transform = {
    'FT_COLOR_INCLUDE_ROOT_TRANSFORM' : 0,
    'FT_COLOR_NO_ROOT_TRANSFORM'      : 1,
    'FT_COLOR_ROOT_TRANSFORM_MAX'     : 2,
}
globals().update(FT_Color_Root_Transform)
