from .casa_functions import getdminfo, getdesc  # noqa
from . import table